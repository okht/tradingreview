# 回看 Design System

回看产品与组件库共用的设计系统：**95 个语义变量、11 个通用 React 组件、1 个周期编辑模式，以及可操作的组件展示页**。0.2.0 基于 OKX 实际页面与语义变量采样，使用 REA 分析公开页面结构。

保留白色主题、黑色主要操作、细灰分隔线和紧凑字段布局。设计参考 OKX 与公开 OKDS 案例，具体样式由本产品维护。

![0.2.0 按钮、字段与语义状态](docs/images/components-0.2.png)

## 规范入口

| 内容 | 文档 |
| --- | --- |
| 颜色、字体、间距、圆角、控件尺寸 | [基础样式](docs/foundations.md) |
| 按钮、表单、标签、信息带、弹窗、页签、表格 | [组件规则](docs/components.md) |
| 周期偏好、K 线、时间与成交展示 | [金融交互模式](docs/patterns.md) |
| 文案、数据边界、键盘与可访问性 | [文案与可访问性](docs/content-and-accessibility.md) |
| 已确认的设计和新增工程封装的区别 | [来源与边界](docs/provenance.md) |
| 修改变量、组件和版本的流程 | [维护约定](docs/contributing.md) |
| 验证结果 | [验证记录](VERIFICATION.md) |

## 本地查看

需要 Node.js 22.12 或以上版本。仓库为私有，克隆需要 GitHub 访问权限。

```sh
git clone https://github.com/okht/huikan-design-system.git
cd huikan-design-system
npm ci
npm run dev
```

展示页地址：`http://127.0.0.1:5184/`。包括基础样式、组件状态、表单校验、弹窗、可编辑周期偏好、4 小时/日/周/月 K 线和缺数据状态。展示页的存储键独立于原型。

```sh
npm test
npm run build
npm run preview
```

`lib/` 为 React 组件构建，`dist/` 为展示页。图表及构造数据只在示例层，未加入核心组件包。

## 在其他项目里复用

此版通过 GitHub 交付源码，未发布到 npm。先在此仓库构建并打包：

```sh
npm ci
npm run build
npm pack
```

然后在目标项目安装生成的包：

```sh
npm install /path/to/okht-huikan-design-system-0.2.0.tgz
```

```jsx
import { Button, Tag, TextField } from '@okht/huikan-design-system';
import '@okht/huikan-design-system/styles.css';

export function Example() {
  return (
    <div className="hk-theme">
      <TextField label="检查项名称" placeholder="例如：核对信息时间" />
      <Button onClick={() => { /* 由业务处理保存 */ }}>保存</Button>
      <Tag tone="green">已清仓</Tag>
    </div>
  );
}
```

核心组件需 React 19。组件样式以 `hk-` 前缀组织，基础变量在 `.hk-theme` 内生效；弹窗与浮层自带主题范围。需要全局品牌覆盖时，请同时覆盖 Portal 上的 `.hk-theme`。

## 在现有产品里只接入变量

```js
import '@okht/huikan-design-system/tokens-global.css';
import { tokens } from '@okht/huikan-design-system/tokens';
// tokens['chart-up'] 可直接传入 Canvas API。
```

产品通过版本化 tgz 依赖以上入口，组件 CSS 引用同一套变量。Scoped 组件使用 `styles.css`，Portal 自带 .hk-theme 范围。修改语义变量后需要重新生成、构建并更新产品锁文件。

## 已确定的约定

- 白色主题，短标题直接表达功能，减少宣传性文案。
- 字段通过图标、边框和间距组织；不用间隔点分隔字段。
- 保留日期范围、成交笔数、币种、单位与来源。
- 方向字段统一显示「买入／卖出」；持仓动作放到复盘语境。
- 普通按钮 40px，图表工具按钮 32px，输入框 44px。
- 保存成功、失败、缺少行情和示例数据分别表达。
- 周期偏好使用编辑草稿，支持增删、排序、恢复默认、取消和保存。
- 图表保留十字线、OHLC、买卖标记和 TradingView 署名。

具体字号例外、断点及状态值以文档和源码为准。

## 结构

```text
tokens/tokens.json           样式变量源文件，每项记录来源
src/tokens.css               自动生成的局部 CSS 变量
src/tokens-global.css        产品使用的全局 CSS 变量
src/tokens.js                Canvas 使用的已解析变量
src/components.jsx           通用组件
src/components.css           组件样式
src/patterns/                受控周期选择器与可选存储适配器
src/index.d.ts               公共类型声明
examples/investment-chart/   构造 K 线与复盘时间过滤示例
gallery/                    可交互组件展示页
docs/                       规则、来源与维护文档
tests/                      组件语义、存储及行情测试
```

修改变量时编辑 `tokens/tokens.json`，再运行 `npm run tokens`。`npm test` 和构建会检查 CSS 与源变量一致。新增组件状态需同步展示页、类型和文档。

## 版本与边界

版本 `0.2.0`，采样日期 `2026-10-21`。实际页面样式、REA 静态分析与产品语义映射分别记录在 [来源与边界](docs/provenance.md)。

本次新增的命名空间、受控组件接口、类型声明和自动化检查用于工程复用。原型页面及其已保存记录未迁移。仓库不包含笔试题、咨询记录、账户数据或真实成交。

4小时K线是构造示例，口径见[图表示例说明](examples/investment-chart/README.md)。此版本尚未经过真人可用性测试或完整无障碍审计。

仓库默认私有，原创内容保留所有权利；第三方依赖遵循各自许可证。参见 [LICENSE](LICENSE) 和 [第三方声明](THIRD_PARTY_NOTICES.md)。
