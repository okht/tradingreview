import type * as React from 'react';
import type * as Dialog from '@radix-ui/react-dialog';

export type ControlSize = 'sm' | 'md';

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'feature' | 'secondary' | 'ghost';
  size?: ControlSize;
}
export const Button: React.ForwardRefExoticComponent<ButtonProps & React.RefAttributes<HTMLButtonElement>>;

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Accessible name, also used as the delayed tooltip text. */
  label: string;
  size?: ControlSize;
}
export const IconButton: React.ForwardRefExoticComponent<IconButtonProps & React.RefAttributes<HTMLButtonElement>>;

export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  tone?: 'gray' | 'green' | 'success' | 'amber' | 'warning' | 'red' | 'danger' | 'info';
}
export const Tag: React.ForwardRefExoticComponent<TagProps & React.RefAttributes<HTMLSpanElement>>;

export interface StatusTagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Controls the semantic icon and color together; text is supplied by the caller. */
  status?: 'success' | 'warning' | 'danger' | 'waiting' | 'info';
}
export const StatusTag: React.ForwardRefExoticComponent<StatusTagProps & React.RefAttributes<HTMLSpanElement>>;

interface FieldDescriptionProps {
  label: React.ReactNode;
  hint?: React.ReactNode;
  error?: React.ReactNode;
  /** Class for the outer field; className applies to the native control. */
  fieldClassName?: string;
}
export type TextFieldProps = FieldDescriptionProps & (
  | (Omit<React.InputHTMLAttributes<HTMLInputElement>, 'children'> & { multiline?: false })
  | (Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'children'> & { multiline: true })
);
export const TextField: React.ForwardRefExoticComponent<TextFieldProps & React.RefAttributes<HTMLInputElement | HTMLTextAreaElement>>;

export interface StatusBadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  status?: 'saved' | 'error';
}
export const StatusBadge: React.ForwardRefExoticComponent<StatusBadgeProps & React.RefAttributes<HTMLSpanElement>>;

export type MetaGroupProps = React.HTMLAttributes<HTMLSpanElement>;
export const MetaGroup: React.ForwardRefExoticComponent<MetaGroupProps & React.RefAttributes<HTMLSpanElement>>;
export interface MetaItemProps extends React.HTMLAttributes<HTMLSpanElement> { icon?: React.ReactNode; }
export const MetaItem: React.ForwardRefExoticComponent<MetaItemProps & React.RefAttributes<HTMLSpanElement>>;

export interface ModalProps extends Omit<React.ComponentPropsWithoutRef<typeof Dialog.Content>, 'title' | 'children' | 'asChild'> {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: React.ReactNode;
  description?: React.ReactNode;
  /** One ref-capable element, passed to Radix Trigger with asChild. */
  trigger?: React.ReactElement;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  /** Preserves the prototype's 740 px wide dialog variant. */
  wide?: boolean;
}
export const Modal: React.ForwardRefExoticComponent<ModalProps & React.RefAttributes<HTMLDivElement>>;

export interface TabItem {
  value: string;
  label: React.ReactNode;
  disabled?: boolean;
  /** ID of an existing tabpanel rendered by the consumer. */
  panelId?: string;
}
export interface TabsProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
  items: TabItem[];
  value: string;
  onValueChange: (value: string) => void;
  'aria-label': string;
}
export const Tabs: React.ForwardRefExoticComponent<TabsProps & React.RefAttributes<HTMLDivElement>>;

export interface DataTableColumn<Row extends object = Record<string, React.ReactNode>> {
  key: Extract<keyof Row, string>;
  label: React.ReactNode;
  align?: 'left' | 'center' | 'right';
}
export interface DataTableProps<Row extends object = Record<string, React.ReactNode>> extends Omit<React.TableHTMLAttributes<HTMLTableElement>, 'children'> {
  caption: React.ReactNode;
  columns: DataTableColumn<Row>[];
  /** Cell values must be renderable React nodes. */
  rows: Row[];
  rowKey?: Extract<keyof Row, string> | ((row: Row, index: number) => React.Key);
}
export function DataTable<Row extends object = Record<string, React.ReactNode>>(props: DataTableProps<Row> & React.RefAttributes<HTMLTableElement>): React.ReactElement;

export interface PeriodOption { id: string; label: string; }
export interface PeriodSelectorProps {
  periods: PeriodOption[];
  value: string;
  onChange: (id: string) => void;
  available: string[];
  favorites: string[];
  /** Return false or reject to keep the editor open and show a save error. */
  onFavoritesChange: (ids: string[]) => void | boolean | Promise<void | boolean>;
  defaultFavorites: string[];
}
export function PeriodSelector(props: PeriodSelectorProps): React.ReactElement;

export interface PeriodPreferences { favorites: string[]; selected: string; }
export interface PeriodPreferenceStore {
  read(): PeriodPreferences;
  saveFavorites(ids: string[], available: string[]): boolean;
  rememberSelected(id: string): boolean;
}
export interface PeriodPreferenceStoreOptions {
  storage: Pick<Storage, 'getItem' | 'setItem'> | null | undefined;
  key: string;
  periods: Array<{ id: string }>;
  defaultFavorites: string[];
  defaultSelected?: string;
}
export function createPeriodPreferenceStore(options: PeriodPreferenceStoreOptions): PeriodPreferenceStore;
