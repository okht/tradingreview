# 第三方声明

本设计系统独立维护，不属于 OKX 官方组件库。OKX/OKDS 公开案例仅作为界面组织参考，未复制其品牌素材、专有字体或组件源码。

| 依赖 | 版本 | 用途 | 许可证 |
| --- | --- | --- | --- |
| React / React DOM | 19.3.1 | 组件运行与展示页 | MIT |
| Radix UI React Dialog | 1.3.1 | 弹窗、焦点与关闭行为 | MIT |
| Radix UI React Tooltip | 1.4.1 | 延迟提示与可访问说明 | MIT |
| Lucide React | 1.60.0 | 通用图标 | ISC |
| Vite | 8.3.4 | 构建与本地预览 | MIT |
| Vite React Plugin | 6.1.2 | React 构建 | MIT |
| Sonner | 2.0.8 | 展示页提示 | MIT |
| TradingView Lightweight Charts | 5.2.1 | 示例 K 线 | Apache-2.0 |
| fancy-canvas | 2.1.0 | 示例图表画布 | MIT |

具体依赖锁定在 package-lock.json。上述直接使用的软件许可证副本见 [public/licenses](public/licenses/)。传递依赖的版权和许可保留在安装包及锁文件中。

Lightweight Charts 仅用于示例层，界面保留 TradingView 标识、署名和官网链接；Apache LICENSE 与 NOTICE 一并保留。核心组件包没有包含图表库或构造行情。

本仓库的原创代码和文档未授予公共开源许可，参见 [LICENSE](LICENSE)。
