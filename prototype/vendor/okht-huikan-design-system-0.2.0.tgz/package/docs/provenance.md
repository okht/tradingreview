# 来源、范围与确认边界

版本 0.2.0，2026-10-21。目标仓库为私有 `okht/huikan-design-system`，此记录不代表已发布到 npm。

## 本轮参考与方法

用户要求用 [REA](https://github.com/morluto/rea) 支撑对 [OKX 策略页面](https://www.okx.com/zh-hans/trading-bot) 的研究，并全面统一回看前端与设计系统。

本轮实跑 REA 6.7.0 的 `analyze-javascript-application`。公开 workspace 与 strategy home 两份脚本合计 200577 bytes，解析 90 个模块，0 次解析失败。证据 ID：`ev_28d1b064cf45dcf4907e730029c987298efc5ea99474d4623cd155f08bc1cd3b`。完整分析证据仅保留在项目本地 `references/rea-okx`。

静态脚本分析用于理解组件结构和实现组织，无法单独证明最终运行样式。颜色、文字、边线和选中状态由浏览器实际 computed styles 采样核对。精简采样记录见 [页面值](reference/okx-computed-tokens.json) 、[语义变量](reference/okx-semantic-tokens.json) 与 [字段状态](reference/okx-control-samples.json)。

| 层级 | 采用内容 | 边界 |
| --- | --- | --- |
| 实际页面 | 白页面、白侧栏、黑顶栏，局部灰选中，小标签与细边线 | 采样页面及日期已记录，不宣称覆盖全部 OKX 页面 |
| 实际语义变量 | 文字层级、分隔线、金融红绿、信息和成功文字 | 变量在 tokens.json 逐项标记来源 |
| 可见强调 | New 标签 #bcff2f、黑字、小圆角 | 回看只用于少量品牌/Agent 标识 |
| 产品映射 | 悬浮/选中角色、尺寸、部分错误文字对比度调整 | 属于回看实现，不称为 OKX 官方规范 |
| 工程实现 | 统一 token 源、scoped/global CSS、Canvas JS、组件 API | 本项目自有代码 |

没有将 OKX 的 JS/CSS 原文、品牌标识、专有字体或素材加入产品或设计系统。页面结构与可见语义被独立实现。REA 属于分析工具，不是 OKX 组件库，也不授予复制第三方代码的许可。

## 版本关系

0.1.0 从回看原型提交 `dd4a6b805ca6bf4552a8227f96468674ebd2842c` 抽取，只有组件库内部 token 校验。0.2.0 根据本轮实际采样更新视觉来源，并增加产品可消费的 global CSS 和 resolved JS，消除两套色值独立维护的问题。

保留用户已经明确的业务交互：对话主导复盘、共用 K 线、单笔背景与证据、固定每页 10 笔、买入/卖出方向、字段不使用间隔点。此次基础样式更新不修改财务计算、数据真实性、账户连接或交易行为。

## 交付内容与排除范围

组件库包含自有规范、通用代码、必要构造示例及精简的公开样式测量。没有账户数据、密钥、真实成交、笔试原文或模型咨询记录。React、Radix、Lucide、Lightweight Charts 等依赖保留适用许可；图表示例保留 TradingView 署名。

产品金融行为由产品测试验证。Gallery 中的历史行情示例仅演示组件交互，不承担生产复盘时点重建。未完成的检查、第三方权限和真人可用性结论以实际验证记录为准。
