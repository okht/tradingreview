# 基础样式

版本 0.2.0，采样日期 2026-10-21。语义变量由 `tokens/tokens.json` 统一生成，产品与组件库共同消费。来源、采样方式与适用范围见 [来源记录](provenance.md)。

## 页面层级

页面和侧栏使用白色，顶栏使用黑色。主要操作为黑底白字，次要操作使用白底细边线。灰色只承载局部悬浮、选中、小标签和需要区分的容器。避免给整块侧栏、普通说明或同步提示铺浅灰、米黄底色。

品牌强调色仅用于少量品牌和 Agent 标识。它不替代金融涨跌、成功或失败语义。业务状态同时使用文字或图标，不能依赖颜色单独传达。

## 颜色

| 角色 | 变量 | 值 | 来源 |
| --- | --- | --- | --- |
| 主文字 | ink | #000 | OKX semantic |
| 次文字 | ink-secondary | #383838 | OKX semantic |
| 辅助文字 | ink-tertiary | #5b5b5b | OKX semantic |
| 禁用文字 | text-disabled | #b3b3b3 | OKX semantic |
| 页面、侧栏、表单 | surface | #fff | OKX 实际页面 |
| 轻容器 | surface-soft | #fafafa | OKX 策略卡片 |
| 悬浮 | surface-hover | #f5f5f5 | 产品交互映射 |
| 选中 | surface-selected | #f0f0f0 | 产品交互映射 |
| 强选中 | surface-active | #e9e9e9 | OKX 选中导航 |
| 小标签 | surface-tag | #f3f3f3 | OKX 筛选按钮 |
| 反色面 | surface-inverse | #000 | OKX 顶栏 |
| 分隔线 | border | #e6e6e6 | OKX semantic |
| 字段边线 | border-strong | #d6d6d6 | 产品映射 |
| 金融绿 | green | #31bd65 | OKX 行情变量 |
| 金融红 | red | #eb4b6d | OKX 行情变量 |
| 正向文字 | green-text | #2b6d17 | OKX semantic success |
| 负向文字 | red-text | #c32e50 | 产品对比度调整 |
| 信息文字 | info | #212121 | OKX semantic info |
| 小面积强调 | accent | #bcff2f | OKX 可见 New 标签 |

`text-primary / secondary / tertiary` 为 ink 角色的兼容别名。`line`、`text` 为旧产品组件的兼容别名。`surface` 已明确表示白色页面；交互状态必须选用对应角色，不能用同一个底色变量覆盖所有状态。

现有人民币股票产品保留红涨绿跌与买入红、卖出绿的展示约定：`chart-up → red`、`chart-down → green`。品牌色、金融色、状态文字分别定义，业务应用决定市场的颜色映射。

普通文字优先使用高对比度的 ink、green-text、red-text。鲜亮金融色用于图形、数值强调和小图标。旧 amber 提示保持兼容 API，仅在需要核对的警告状态中使用浅橙背景与深色文字。

## 排版与控件

系统字体栈为 system-ui、-apple-system、BlinkMacSystemFont、Segoe UI、PingFang SC、Microsoft YaHei、Noto Sans CJK SC、sans-serif。基础文字 14px、行高 1.6；辅助文字 12px；紧凑控件 13px。金额、日期与计数使用等宽数字。

标题默认 24 / 17 / 14px。常规按钮 40px、工具按钮 32px、输入框 44px。单行字段使用黑6%浅填充，长文本保持白底。输入框与选择器使用 8px 圆角，主要按钮保持胶囊形。表格以 10px 14px 单元格间距维持密度，宽表格只在自身容器横向滚动。

间距使用 4 / 8 / 12 / 16 / 20 / 24 / 32px。页面组合可以使用必要的局部间距，避免为套用令牌破坏信息密度。

## 交互

焦点使用黑色边线和键盘可见外轮廓，填充沿用默认状态。悬浮、按下、选中、禁用各自有独立变量。Tooltip 延迟 350ms 显示，弹窗打开时焦点落在容器，防止关闭按钮提示自动展开。关闭后仍由 Radix 恢复触发位置。

浮层使用同一套 popover/modal 阴影，不叠加输入框阴影。减少动态效果偏好停用过渡。桌面和窄屏都保留可达的关闭、提交、分页入口。

## 共享入口

- `@okht/huikan-design-system/tokens-global.css`：在 :root 注入变量，现有产品使用此入口。
- `@okht/huikan-design-system/tokens.css`：只在 .hk-theme 内注入变量，适合局部嵌入。
- `@okht/huikan-design-system/tokens`：导出已解析别名的 tokens 对象，供 Canvas 配置使用。
- `@okht/huikan-design-system/tokens.json`：包含类型、来源与原始别名。

禁止编辑生成的 CSS/JS。修改 JSON 后执行 `npm run tokens`。构建同时验证 scoped CSS、global CSS、JS 数值一致，并检查引用是否存在、是否循环。

## 控件状态矩阵

以下按钮与状态色来自实际 OKX 语义变量。纯色默认页、侧栏与普通同步提示保持白色；成功、失败、警告仅用于对应的小范围状态。

| 对象 | 默认 | 悬浮 | 按下 / 聚焦 | 禁用 |
| --- | --- | --- | --- | --- |
| 主按钮 | #000 / 白字 | #2c2c2c | #525252 | 黑3%底 / #b3b3b3字 |
| feature 辅助按钮 | #e6ffb0 / #2b6d17 | #c4dd8f | #a6bc74 | 黑3%底 / #b3b3b3字 |
| 单行字段 | 黑6%填充 / 透明边线 | 黑8%填充 | 仍黑6%填充 / 黑1px边线 | 黑3%填充 / #b3b3b3字 |
| 多行字段 | 白底 / 细边线 | 白底 / 黑边线 | 白底 / 黑边线 | 浅灰底 / 禁用文字 |

字段默认和聚焦状态由 OKX 实际金额输入框采样。悬浮黑8%为产品映射，尚未声明该值来自该输入框的精确采样。focus-visible 另保留清晰外轮廓，供键盘用户定位；不叠加阴影。

成功状态使用 #e9f4d1 与 #2b6d17；失败使用 #fee0e3 与 #c32e50；需要用户核对的警告使用 #ffedcb 与 #ba5d00。信息状态保持中性。状态同时提供文字或图标，不以颜色替代语义。

field invalid 使用红边线和浅红帮助区域；readonly 使用 surface-soft；disabled 使用专门的背景与文字角色，不通过降低整个控件透明度表示。
