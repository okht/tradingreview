# 组件规则

原型已经共享 `Button`、`IconButton`、`Tag`，其余内容通过页面组合实现。本仓库把可复用部分封装为公共组件，使用 `hk-` 类名前缀并在 `.hk-theme` 内应用基础样式。公开包名为 `@okht/huikan-design-system`；GitHub 私有仓库交付与 npm 发布分别管理。

0.2.0 更新：组件统一消费语义 token；普通信息保持中性，成功/失败/需核对状态使用各自浅色底与高对比文字。图标按钮使用延迟 Tooltip，弹窗打开聚焦容器，避免自动显示关闭提示。

## 公共接口

当前范围包含 10 个核心组件，以及 1 个周期选择模式。`MetaGroup` 与 `MetaItem` 分别计数；`PeriodSelector` 作为组合模式维护。

| 组件 | 主要属性 | 来源与职责 |
| --- | --- | --- |
| `Button` | `variant: primary/feature/secondary/ghost`，`size: sm/md`，原生按钮属性 | 从原型共享组件抽取 |
| `IconButton` | `label`，`size: sm/md`，原生按钮属性 | 从原型抽取，提供可访问名称和 DOM 引用 |
| `Tag` | `tone: gray/green/success/amber/warning/red/danger/info`，`children` | 从原型抽取，表示静态来源或状态 |
| `StatusTag` | `status: success/warning/danger/waiting/info`，`children` | 状态图标与色调统一映射，文案由调用方提供 |
| `TextField` | `label`，`hint`，`error`，`multiline`，原生输入属性 | 本次封装标签、说明、输入和错误关联 |
| `StatusBadge` | `status: saved/error` | 本次封装保存状态，不处理存储 |
| `MetaGroup`、`MetaItem` | 分组内容；`MetaItem` 接受 `icon`、`children` | 本次封装图标信息带 |
| `Modal` | `open`，`onOpenChange`，`title`，`description`，`trigger`，`children`，`footer` | 本次封装 Radix Dialog 组合 |
| `Tabs` | `items: [{ value, label, disabled? }]`，`value`，`onValueChange` | 本次封装受控页签 |
| `DataTable` | `caption`，`columns: [{ key, label, align? }]`，`rows`，`rowKey` 默认 `id` | 本次封装表头、对齐及滚动容器 |
| `PeriodSelector` | `periods`，`value`，`onChange`，`available`，`favorites`，`onFavoritesChange`，`defaultFavorites` | 从原型交互抽取为受控周期选择器 |

以上接口属于本次工程封装。具体导出、类型及示例与本仓库源码保持同步；原型的页面组件不自动成为公共 API。

## 按钮与图标按钮

`feature` 使用浅绿色与深绿文字，服务方法整理等辅助动作；`primary` 使用黑底白字，服务当前任务的主要动作；`secondary` 使用白底细边框，承载次要动作；`ghost` 保持轻量，用于恢复默认等低优先级操作。同一操作区域应让主动作易于识别。

| 规格 | 常规 `md` | 小号 `sm` |
| --- | --- | --- |
| 最小高度 | 40px | 32px |
| 文字字号 | 13px | 12px |
| 文字按钮内边距 | 8px 16px | 4px 10px |
| 圆角 | 胶囊形 | 6px |
| 图标按钮宽高 | 40px | 32px |

默认 `type="button"`。表单提交明确声明 `type="submit"`。禁用动作使用原生 `disabled`；交互态不覆盖禁用态。图标按钮必须有完整动作名称，例如「复位 K 线视图」。图标尺寸由使用位置确定，32px 工具按钮通常配 14–16px 图标。

## 标签、保存状态、信息带

`Tag` 使用 12px 辅助字、24px 最小高度、4px 圆角和轻量底色。静态标签不提供手形、箭头或悬浮变色。需要点击的「查看模式说明」使用按钮语义。

`StatusTag` 默认配备 13px 语义图标：成功为圆形勾选、需要核对为警示三角、失败为圆形叉号、等待为时钟、普通信息为圆形信息标记。状态同时由图标、短文案和底色表达；图标对辅助技术隐藏，保留可读文案，避免重复播报。来源和版本标签继续使用 `Tag`。

`StatusBadge` 展示调用方确认的保存状态。成功显示设备或勾选图标及短文案；失败同步更新图标和文案，提供可理解的后续操作。调用方完成持久化核对后才能传入 `saved`。

`MetaGroup` 组织「日历图标＋日期范围」「记录图标＋成交笔数」。原型采用 12px 文字、14px 图标、5px 8px 内边距、6px 圆角与细分隔线；窄屏可换行，保留完整时间范围与笔数。证券代码、指标数值和表格内容无需全部包入信息带。

## 表单

标签置于输入框上方，标签与输入间距 8px。输入框最小高度 44px、字号 13px、内边距 10px 12px、圆角 8px，单行使用黑6%填充与透明边线。焦点保持填充，显示黑1px边线；多行文本保持白底。多行输入最小高度 60px，允许纵向调整。

`label` 提供持久名称；`hint` 解释格式或用途；`error` 说明问题和修正方式。占位文字可给示例。错误信息与输入建立关联，使用 `aria-invalid`；异常时保留用户已经输入的内容。

原型中的嵌入式自定义问题输入外框高 44px，内部按钮高 32px。这属于组合输入模式。原生输入框获得焦点时，父容器统一反馈，避免双重阴影。

## 弹窗

桌面默认宽 `min(550px, 100vw - 32px)`、最大高度 90vh、内边距 28px。原型宽弹窗为 740px，公共组件是否暴露宽度变体以实际接口为准。遮罩使用 `--overlay`，模糊 3px，浮层圆角 12px。

520px 以下采用满宽底部弹层，最大高度 `100dvh - 24px`，上圆角 16px，底部考虑安全区。内容长时可滚动，主要动作保持可达。

标题与说明始终提供；关闭图标、取消和 Escape 使用同一关闭路径。Radix 管理焦点约束，关闭后返回触发控件。`asChild` 下的组件需要透传事件、原生属性和 `ref`。

## 页签、表格与周期选择

`Tabs` 是受控组件。公共组件采用深色字与浅灰选中底色，禁用项保持可识别；键盘及 ARIA 页签语义由组件处理。这是本次工程封装的组件样式。原型主导航使用指示线、页面切换按钮和 `aria-current="page"`，流程步骤使用 `aria-current="step"`。业务接入时按用途选择语义。

`DataTable` 保留可访问表名、列标题和稳定行键。金额及数量右对齐，数字采用等宽数字；方向用「买入」「卖出」标识。原型表格为 12px 字号，单元格默认内边距 10px 14px，行分隔线 `#eee`，悬浮底色 `#fafafa`。成交表有紧凑行高例外。窄屏在表格容器内横向滚动。

`PeriodSelector` 的完整数据、草稿、持久化与失败约定见[周期偏好模式](patterns.md)。组件负责选择与编辑交互，调用方提供行情可用范围、当前周期和收藏状态。

`periods` 使用 `{ id, label }` 列表，`available`、`favorites` 和 `defaultFavorites` 使用周期 ID 数组。`onChange(id)` 处理当前周期切换；`onFavoritesChange(nextFavorites)` 可以异步保存。成功后调用方更新 `favorites`，回调完成后关闭编辑弹窗；返回 `false`、抛出异常或 Promise 拒绝会保留弹窗与草稿。组件本身不写入浏览器存储，也不发送成功 toast。
